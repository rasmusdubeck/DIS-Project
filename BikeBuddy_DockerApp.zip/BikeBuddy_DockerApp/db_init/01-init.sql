DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username TEXT NOT NULL,
    email TEXT NOT NULL,
    skill_level INTEGER NOT NULL,
    postal_code VARCHAR(4) NOT NULL
);

\COPY users(id, username, email, skill_level, postal_code)
FROM '/docker-entrypoint-initdb.d/users.csv'
WITH (FORMAT csv, HEADER true);
